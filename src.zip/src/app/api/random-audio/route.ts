import { NextRequest, NextResponse } from 'next/server';
import { Storage } from '@google-cloud/storage';
import fs from 'fs';
import path from 'path';

// Check if credentials file exists
const credentialsPath = process.env.GOOGLE_CLOUD_CREDENTIALS || './google-credentials.json';
const credentialsExist = fs.existsSync(path.resolve(process.cwd(), credentialsPath));

console.log(`Credentials file exists: ${credentialsExist}`);

// Initialize Google Cloud Storage if credentials exist
let storage: Storage | undefined;
if (credentialsExist) {
  storage = new Storage({
    keyFilename: credentialsPath,
    projectId: process.env.GOOGLE_CLOUD_PROJECT_ID,
  });
}

const bucketName = process.env.GOOGLE_CLOUD_BUCKET_NAME || 'audio-manga';

export async function GET(request: NextRequest) {
  console.log('API route triggered with params:', request.nextUrl.searchParams.toString());
  console.log('Environment variables:', { 
    projectId: process.env.GOOGLE_CLOUD_PROJECT_ID, 
    bucketName,
    credentialsPath
  });

  const searchParams = request.nextUrl.searchParams;
  const mood = searchParams.get('mood');

  if (!mood) {
    return new NextResponse('Mood parameter is required', { status: 400 });
  }

  // Check if configuration is missing
  if (!credentialsExist) {
    console.error('ERROR: Google Cloud credentials file not found at', path.resolve(process.cwd(), credentialsPath));
    return new NextResponse(
      'Server configuration error: Google Cloud credentials missing', 
      { status: 500 }
    );
  }

  if (!process.env.GOOGLE_CLOUD_PROJECT_ID) {
    console.error('ERROR: GOOGLE_CLOUD_PROJECT_ID environment variable not set');
    return new NextResponse(
      'Server configuration error: Project ID missing', 
      { status: 500 }
    );
  }

  if (!storage) {
    console.error('ERROR: Storage client not initialized');
    return new NextResponse(
      'Server configuration error: Storage client not initialized', 
      { status: 500 }
    );
  }

  try {
    console.log(`Accessing bucket: ${bucketName}`);
    const bucket = storage.bucket(bucketName);
    
    // List all files in the mood directory
    console.log(`Looking for files with prefix: audio/${mood}/`);
    const [files] = await bucket.getFiles({
      prefix: `audio/${mood}/`,
      delimiter: '/',
    });
    
    console.log(`Found ${files.length} files for mood: ${mood}`);
    
    // Filter to only audio files
    const audioFiles = files.filter((file) => /\.(mp3|wav|ogg)$/i.test(file.name));
    console.log(`After filtering, found ${audioFiles.length} audio files`);
    
    if (audioFiles.length === 0) {
      return new NextResponse(`No audio files found for mood: ${mood}`, { status: 404 });
    }

    // Pick a random file
    const randomFile = audioFiles[Math.floor(Math.random() * audioFiles.length)];
    console.log(`Selected file: ${randomFile.name}`);
    
    // Generate a signed URL that expires in 15 minutes
    console.log('Generating signed URL');
    const [url] = await randomFile.getSignedUrl({
      version: 'v4',
      action: 'read',
      expires: Date.now() + 15 * 60 * 1000, // 15 minutes
    });
    
    console.log('Successfully generated signed URL');
    
    // Create response with cache control headers
    const response = NextResponse.json({ url });
    
    // Cache the result for 5 minutes to improve performance
    response.headers.set('Cache-Control', 'public, max-age=300');
    
    return response;
  } catch (error) {
    console.error('Error accessing audio files:', error);
    // More detailed error logging
    if (error instanceof Error) {
      console.error('Error message:', error.message);
      console.error('Error stack:', error.stack);
    }
    return new NextResponse(`Error accessing audio files: ${error instanceof Error ? error.message : 'Unknown error'}`, { status: 500 });
  }
}
