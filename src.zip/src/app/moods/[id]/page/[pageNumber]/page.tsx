"use client"

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { ArrowLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import CategorySelector from '@/components/CategorySelector';

interface PageClassification {
  id: number;
  category: string;
  confidence: number | null;
  explanation: string | null;
}

export default function PageView() {
  const params = useParams();
  const router = useRouter();
  const { id, pageNumber } = params;
  const [classification, setClassification] = useState<PageClassification | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function fetchClassification() {
      try {
        const { data, error: fetchError } = await supabase
          .from('manga_page_classifications')
          .select('id, category, confidence, explanation')
          .eq('chapter_id', id)
          .eq('page_number', pageNumber)
          .single();

        if (fetchError) throw fetchError;
        setClassification(data);
      } catch (err) {
        setError(err as Error);
        console.error('Error fetching classification:', err);
      } finally {
        setLoading(false);
      }
    }

    fetchClassification();
  }, [id, pageNumber]);

  const imagePath = `/chapters/${id}/${pageNumber}.jpg`;

  return (
    <div className="min-h-screen bg-black flex flex-col">
      {/* Header with back button and category selector */}
      <div className="w-full bg-gray-900 p-4">
        <div className="container mx-auto flex justify-between items-center">
          <button
            onClick={() => router.back()}
            className="text-white flex items-center gap-2 hover:text-gray-300 transition"
          >
            <ArrowLeft size={24} />
            <span>Back to Classifications</span>
          </button>

          {!loading && !error && classification && (
            <div className="flex items-center gap-4">
              <div className="text-white">Category:</div>
              <div className="w-48">
                <CategorySelector
                  chapterId={Number(id)}
                  pageNumber={Number(pageNumber)}
                  currentCategory={classification.category}
                  onCategoryChange={(newCategory) => 
                    setClassification(prev => prev ? {...prev, category: newCategory} : null)
                  }
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Image container */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="relative max-w-full max-h-[90vh]">
          <Image
            src={imagePath}
            alt={`Page ${pageNumber}`}
            width={1000}
            height={1500}
            className="object-contain"
            priority
          />
        </div>
      </div>

      {/* Classification details */}
      {!loading && !error && classification && (
        <div className="w-full bg-gray-900 p-4">
          <div className="container mx-auto text-white">
            {classification.confidence && (
              <p className="mb-2">
                Confidence: {(classification.confidence * 100).toFixed(1)}%
              </p>
            )}
            {classification.explanation && (
              <p className="italic text-gray-300">
                "{classification.explanation}"
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
} 